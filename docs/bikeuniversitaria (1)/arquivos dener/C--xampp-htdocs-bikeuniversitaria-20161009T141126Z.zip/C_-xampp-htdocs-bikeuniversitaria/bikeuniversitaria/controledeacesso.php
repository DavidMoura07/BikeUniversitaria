<?php
	include("conecta.php");
	$cartao = $_GET['cartao'];
	$preco = 1.5;
	$busca = "select * from usuarios where (cartao like ".$cartao.");";
	if($usuario = mysql_query($busca)){
		$linhausuario = mysql_fetch_array($usuario);
		
		$idusuario = $linhausuario["idusuarios"];
		$nomeusuario = $linhausuario["nome"];
		$saldousuario = $linhausuario["saldo"];
		
		$queryacessos = "SELECT COUNT(usuarios_idusuarios) AS qtd_acesso FROM log WHERE (CAST(datahora AS DATE) LIKE CURRENT_DATE) AND (usuarios_idusuarios LIKE '".$idusuario."');";
		$acessos = mysql_query($queryacessos);
		$linha_acessos = mysql_fetch_array($acessos);
		$qtd_acessos = $linha_acessos["qtd_acesso"];
		echo "<br>$qtd_acessos";
		if(!$qtd_acessos){
			if($saldousuario >= $preco){
				$acesso = 1;
				$saldousuario -= $preco;
				$atualizasaldo = "UPDATE `usuarios` SET `saldo` = '".$saldousuario."' WHERE `usuarios`.`idusuarios` = ".$idusuario.";";
				
				//atualiza o saldo do usuario
				if(mysql_query($atualizasaldo)){
					echo "<br>Saldo atualizado com sucesso!";
				}else{
					echo "<br>Ocorreu um erro ao atualizar saldo!";
				}
				
				//atualiza tabela de log
				$sql_insert = "insert into log (`usuarios_idusuarios`, `saldousuario`) values ('$idusuario','$saldousuario')";
				if(mysql_query($sql_insert)){
					echo "<br>Log atualizado com sucesso!";
				}else{
					echo "<br>Ocorreu um erro ao atualizar Log!";
				}
				
			}else{
				$acesso = 2;
				echo "<br>Falta de saldo";
			}
		}else{
			$acesso = 1;
			//atualiza tabela de log
			$sql_insert = "insert into log (`usuarios_idusuarios`, `saldousuario`) values ('$idusuario','$saldousuario')";
			if(mysql_query($sql_insert)){
				echo "<br>Log atualizado com sucesso!";
			}else{
				echo "<br>Ocorreu um erro ao atualizar Log!";
			}
			echo "<br>log atualizado, saldo nao alterado";
		}
	}else {
		$acesso = 3;
		echo "<br>cartao nao CADASTRADO!";
	}
//acesso==1 PREMITIDO
//acesso==2 NEGADO POR FALTA DE SALDO
//acesso==3 CARTAO NAO CADASTRADO	
?>