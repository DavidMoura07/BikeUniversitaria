<?php

	/*	
	all the 'echo' from the server will be interpreted by Arduino, so the shorter the faster works arduino, plus the lcd display in
	my case has just 16 characters per line, so take this into consideration when printing. 
	Arduino reads all the content printed and it looks for a "XXX" succession: finding this succession is interpreted like "from now on print
	everything on the display". (that's not the smartest solution in the world because if you have to print datas that have "XXX", Arduino 
	would print them out. In my solution it works great, but pay attention to that)
	I also stated that after an "XXX" is found I look for a "." which is interpreted by Arduino as a newline for the display, and if a
	message ends up with a ';' then I know that there must have been an error from the server (ie wrong code, no autorization,...) so
	Arduino knows that has to light up the red error led.
	
	Since you create the messages that Arduino will read, pay attention to create them so that Arduino knows everytime how to handle them		
	*/
	
	// Arduino has sent a request with the id of the card, so apache will get the code and do the stuff you need
	if(isset($_GET['code']))
	{	// try to connect to the Postgresql db	
	 	$db = pg_pconnect("host=localhost dbname='Timbratore' user=postgres password=pargola port=5432");
		if (!$db)
			// if an error has been found, then postgres in unreachable at the moment
			die("XXX .postgresql down;");
		else
		{	// do some stuff when a key is read
		}
		pg_close($db);
		
	}

	// Arduino has sent a request for the time: this way you can display the time without having a dedicated real time clock
	else if((isset($_GET['time'])))
	{	$tmp=time();
		$orario = date('d/m/Y H:i', $tmp);
		echo "XXX".$orario;
	}
?>













